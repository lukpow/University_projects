# include <math.h>
# include "main.h"

double ForwardPriceSimp(double S, double r, double T, double q) {
  return S*((1+r*T)/(1+q*T));
}







// [[Rcpp::export]]



double ForwardPrice(double S, double r, double T, double q) {
  return S*exp((r-q)*T);
}











double N(double x) {
  return 0.5*(1+erf(x/sqrt(2)));
  }







// [[Rcpp::export]]



double Calll(double S, double X, double r, double q, double v, double T) {
  double d1=N((log(S/X)+(r-q+pow(v,2)/2)*T)/(v*sqrt(T)));
  double d2=N((log(S/X)+(r-q-pow(v,2)/2)*T)/(v*sqrt(T)));
  return S*exp(-q*T)*d1-X*exp(-r*T)*d2;
}







// [[Rcpp::export]]




double ImpVolCall(double c, double S, double X, double r, double q, double T) {
  double sigmaL=0;
  double sigmaH=2;
  double sigmaM;

  while (Calll(S, X, r, q, sigmaH, T) < c) {
    sigmaH = sigmaH * 2.0;
    if (sigmaH > 100){
      return -1;
    }
  }
  while (sigmaH - sigmaL > 1e-6) {
    sigmaM = 0.5 * (sigmaL + sigmaH);
    double price = Calll(S, X, r, q, sigmaM, T);

    if (price > c) {
      sigmaH = sigmaM;
      } else {
      sigmaL = sigmaM;
      }
    }
  return sigmaM;

}

