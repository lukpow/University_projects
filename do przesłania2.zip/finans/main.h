# include <windows.h>
# define DLL_EXPORT __declspec ( dllexport )
extern "C"
{
    double DLL_EXPORT ForwardPriceSimp(double S, double r,double T, double q);
    double DLL_EXPORT ForwardPrice(double S, double r, double T, double q);
    double DLL_EXPORT N(double x);
    double DLL_EXPORT Calll(double S, double X, double r, double q, double v, double T);
    double DLL_EXPORT ImpVolCall(double c, double S, double X, double r, double q, double T);


}

