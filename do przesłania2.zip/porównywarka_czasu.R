install.packages("pracma")
library(pracma)

powtorzen=10000
rezultat_nzskal=matrix(0,3,3)
rezultat_skal=matrix(0,3,3)

 
rN=function(x) {  
  return (0.5*(1+erf(x/sqrt(2))))  
} 

rCall=function( S,  X,  r,  q,  v,  T) {  
   d1=rN((log(S/X)+(r-q+(v^2)/2)*T)/(v*sqrt(T)))  
   d2=rN((log(S/X)+(r-q-(v^2)/2)*T)/(v*sqrt(T)))  
  return(S*exp(-q*T)*d1-X*exp(-r*T)*d2)  
}  

rImpVolCall=function( c,  S,  X,  r,  q,  T) {  
   sigmaL=0  
   sigmaH=2  
   
  while (rCall(S, X, r, q, sigmaH, T) < c) { 
    sigmaH = sigmaH * 2.0
    if (sigmaH > 100){
      return -1
    }
  } 
  while (sigmaH - sigmaL > 1e-6) { 
    sigmaM=0.5*(sigmaL + sigmaH)
     price = rCall(S, X, r, q, sigmaM, T) 
    
    if (price > c) { 
      sigmaH = sigmaM
    } 
    else { 
      sigmaL = sigmaM  
    } 
  } 
  return (sigmaM)
  
} 


koll=c()
kk=c(95,100,105)
for (k in 1:length(kk)){
     koll[k]=rCall(100, kk[k], 0.05,  0.2,0.05,1) 
}


sprawdzaczr=function(p,k){
  
  for (i in 1:powtorzen){
    rImpVolCall(p,100,k, 0.05,  1, 0.02)
  }
  
}

for (i in 1:length(kk)){
  rezultat_skal[i,1]=system.time(sprawdzaczr(koll[i],kk[i]))[3]/powtorzen
}



for (i in 1:length(kk)){
  rezultat_nzskal[i,1]=system.time(sprawdzaczr(koll[i],kk[i]))[3]
}



library(Rcpp)


sprawdzaczc=function(p,k){
  
  for (i in 1:powtorzen){
    ImpVolCall(p,100,k, 0.05,  1, 0.02)
  }
  
}

for (i in 1:length(kk)){
  rezultat_skal[i,2]=system.time(sprawdzaczc(koll[i],kk[i]))[3]/powtorzen
}

for (i in 1:length(kk)){
  rezultat_nzskal[i,2]=system.time(sprawdzaczc(koll[i],kk[i]))[3]
}



for (i in 1:length(kk)){
  rezultat_skal[i,3]=rezultat_skal[i,1]/rezultat_skal[i,2]
  rezultat_nzskal[i,3]=rezultat_nzskal[i,1]/rezultat_nzskal[i,2]
  
}

rezultaty=data.frame(rezultat_skal,rezultat_nzskal)
colnames(rezultaty)=c("Przeskalowany czas R","Przeskalowany czas C++","Stosunek przeskalowanych R i C++","Nieprzeskalowany czas R","Nieprzeskalowany czas C++","Stosunek nieprzeskalowanych R i C++")
rownames(rezultaty)=c("K=95","K=100","K=105")
